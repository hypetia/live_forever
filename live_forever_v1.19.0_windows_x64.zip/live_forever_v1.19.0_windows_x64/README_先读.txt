封锁区：余生 v1.19.0
新版包含受击稳身、重型正面抗性、迅捷扑击和有预告的区域巡群。
体验营地新机制请新开战役。游戏中O分配装备、K制作，F5管理营地，F6保存、F9读档、F11全屏。
源码、玩法与验证：https://github.com/hypetia/live_forever
运行包放在GitHub下载分支 downloads-v1.19.0。
Windows64位：完整解压，双击LiveForever.exe；不需要安装Godot或Python。
