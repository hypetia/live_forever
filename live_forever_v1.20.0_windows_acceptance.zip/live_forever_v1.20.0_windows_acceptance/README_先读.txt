封锁区：余生 v1.20.0
新版整理夜间准备、制作、装备、营地和人物界面：地图、岗位、物资分栏，统一配色与导航。
建议F2新开战役。游戏中O分配装备、K制作，F5管理营地，F6保存、F9读档、F11全屏。
源码、玩法与验证：https://github.com/hypetia/live_forever
运行包放在GitHub下载分支 downloads-v1.20.0。
可选的Windows真机验收：双击 windows_acceptance.cmd，默认约30分钟，会主动操控测试窗口。
正常玩游戏只需双击 LiveForever.exe。验收结束后，把本文件夹中的 AcceptanceResults-* 结果文件夹压缩发回即可。
验收使用独立测试存档目录，不覆盖平常游戏存档。本包包含主游戏和独立验收程序，无需另下载。
当前开发环境未完成Windows真机验收；请以你机器上的实际报告为准。
