封锁区：余生 v1.22.0

完整解压，运行 ./LiveForever.x86_64。
离线运行，无需安装 Godot 或 Python。
B 建造床铺与生活设施；K 厨房和制作；F5 营地；O 装备；H 安防与迁居。
查看时自动暂停。确认开工后自动继续；右键/Esc返回，空格返回并继续。
说明：https://github.com/hypetia/live_forever/blob/main/docs/CAMP_WORKFLOW.md
源码提交：10793f71a3b15094a72ab985c779af824d7b79e6
