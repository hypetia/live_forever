封锁区：余生 v1.21.0
新版区分机械零件、耐用工具包和一次性开锁器；工作台工具可保养，零件与工具支持批量生产和按库存补产。K工作台安排生产，K生产计划暂停或继续，O工具栏分配装备。
建议F2新开战役。游戏中O分配装备、K制作，F5管理营地，F6保存、F9读档、F11全屏。
源码、玩法与验证：https://github.com/hypetia/live_forever
运行包放在GitHub下载分支 downloads-v1.21.0。
Windows64位：完整解压，双击LiveForever.exe；不需要安装Godot或Python。
