class_name WorkshopView
extends RefCounted
## On-demand facility pages: recipes, tier benefits, storage and campaign devices.

static func render(ui: CampaignInterface) -> Panel:
	var game := ui.game
	ui.workshop_recipes.clear()
	ui.production_counts.clear();ui.production_modes.clear();ui.production_actions.clear()
	ui.workshop_owner_choices.clear()
	ui.workshop_upgrade = null
	var window := ui.panel(ui.root,Vector2(25,20),Vector2(1390,860))
	ui.label(window,"营地工作",Vector2(25,17),Vector2(1080,40),27,GameUi.TEXT)
	ui.button(window,"返回 · 右键 / Esc",Vector2(1130,17),Vector2(230,40),ui.close_workshop)
	ui.label(window,"空格：返回并继续",Vector2(25,812),Vector2(220,28),17,GameUi.SECONDARY)
	var living_row := 0
	for index in range(game.survivors.size()):
		var actor: Survivor = game.survivors[index]
		if actor.health <= 0: continue
		var choose := ui.button(window,actor.display_name,Vector2(270+living_row*210,73),Vector2(198,38),func(): game.select_survivor(index); ui._create_workshop())
		GameUi.tab(choose,game.selected_id==index)
		choose.disabled = actor.health <= 0
		living_row += 1
	GameUi.paper(window,Rect2(0,0,1390,860))
	GameUi.line(window,Vector2(250,72),Vector2(250,828))
	var pages := [["workbench","工作台"],["kitchen","厨房"],["water","饮水处理"],["garden","种植与采集"],["construction","建造"],["storage","装备维护"],["campaign","撤离工程"],["production","生产计划"]]
	for index in range(pages.size()):
		var page: Array = pages[index]
		var tab := ui.button(window,page[1],Vector2(25,126+index*57),Vector2(210,46),func(): ui.workshop_section = page[0]; ui._create_workshop())
		GameUi.tab(tab,ui.workshop_section==page[0])
	var station := "stove" if ui.workshop_section == "kitchen" else "workbench"
	if ui.workshop_section in ["workbench","kitchen"]:
		ui.workshop_summary = ui.label(window,game.facilities.title(station),Vector2(270,150),Vector2(720,38),23,game.GOLD)
		var benefit: String
		if station == "stove":
			benefit = "烹饪效率 +%d%%" % roundi((game.facilities.rate(station)-1)*100)
		else:
			benefit = "制作效率 %+d%%  /  工具状态 %d%%" % [roundi((game.facilities.rate(station)*game.production.rate()-1)*100),game.production.condition]
		ui.label(window,benefit,Vector2(270,202),Vector2(740,38),16)
		var upgrade: String = game.facilities.next_upgrade(station)
		if not upgrade.is_empty():
			var recipe: Dictionary = FacilitySystem.RECIPES[upgrade]
			ui.workshop_upgrade = ui.button(window,"升级至 Lv.%d · %d秒" % [recipe["to"],recipe["seconds"]],Vector2(1040,150),Vector2(305,40),func(): _start(ui,upgrade))
			var error: String = game.facilities.job_error(game,upgrade)
			ui.workshop_upgrade.disabled = game.cycle.phase != "day" or not error.is_empty() or not game.inventory.can_take(recipe["cost"])
			ui.workshop_upgrade.tooltip_text = recipe["hint"]+"\n取消施工退还材料。\n"+error
			GameUi.primary(ui.workshop_upgrade)
			ui.label(window,ShelterInventory.describe(recipe["cost"]),Vector2(1040,202),Vector2(305,45),15,game.GOLD)
			for job in game.expansion.jobs:
				if job["kind"] == upgrade:
					ui.workshop_upgrade.text = "升级施工中 · %d%%" % roundi(100*float(job["elapsed"])/float(job["duration"]))
		else: ui.label(window,"已达到最高等级",Vector2(1040,158),Vector2(305,35),19,game.GOLD)
	elif ui.workshop_section in ["water","garden","construction"]:
		var titles:Dictionary={"water":"饮水处理","garden":"种植与采集","construction":"床铺与生活设施"}
		var hints:Dictionary={"water":"煮沸需炉灶；过滤需沉淀过滤器。","garden":"种植箱内播种、施肥，成熟后收获。","construction":"床、取暖炉和集水器先选位置；生活设施完工后固定安装。"}
		ui.label(window,titles[ui.workshop_section],Vector2(270,150),Vector2(1070,38),23,game.GOLD)
		ui.label(window,hints[ui.workshop_section],Vector2(270,204),Vector2(1070,40),17,GameUi.SECONDARY)
	elif ui.workshop_section=="production":
		ui.label(window,"生产计划",Vector2(270,150),Vector2(1070,38),23,game.GOLD)
		ui.label(window,"工人空闲时执行，逐件扣料。手动命令暂停计划，夜间暂停施工。",Vector2(270,204),Vector2(1070,40),17,GameUi.SECONDARY)
	elif ui.workshop_section == "storage":
		ui.label(window,"装备仓库 · 弹药%d发" % game.expansion.ammo,Vector2(270,150),Vector2(1070,38),23,game.GOLD)
		ui.label(window,"维修：材料2，恢复60耐久。",Vector2(270,204),Vector2(1070,32),16)
	else:
		ui.label(window,"第%d/35天 · %s" % [game.expansion.day(game),SurvivalExpansion.STAGES[game.expansion.stage]],Vector2(270,150),Vector2(1070,38),23,game.GOLD)
		ui.label(window,game.expansion.objective(game),Vector2(270,204),Vector2(1070,48),17)
	var scroll := ScrollContainer.new()
	ui.workshop_scroll = scroll
	scroll.position = Vector2(270,270)
	scroll.size = Vector2(1090,558)
	window.add_child(scroll)
	var body := Control.new()
	body.custom_minimum_size = Vector2(1060,1)
	scroll.add_child(body)
	var kinds: Array = []
	match ui.workshop_section:
		"workbench": kinds = ["craft"]+GearCatalog.ITEMS.keys()
		"kitchen": kinds = ["cook","cook_batch","cook_stew","cook_pot"]+(["balanced","broth","salad","dry_meat"] if game.camp.enabled else [])
		"water":kinds=["boil_water","filter_water"] if game.camp.enabled else []
		"garden":kinds=["plant_veg","plant_herbs","fertilize","harvest","extract_seeds","check_trap"] if game.camp.enabled else []
		"construction":kinds=["bed","heater","filter","barricade","repair_shelter"]+(["planter","pantry","trap","settling_filter","backup_power"] if game.camp.enabled else [])
		"campaign": kinds = GearCatalog.PROJECTS.keys().filter(func(kind): return not kind in ["ammo","service_tools"])
		"production":WorkshopProductionView.page(ui,body)
		"storage":
			for index in range(game.expansion.gear.size()): _storage_card(ui,body,game.expansion.gear[index],index)
			if game.expansion.gear.is_empty(): ui.label(body,"暂无装备",Vector2(15,20),Vector2(1200,40),18)
	if ui.workshop_section == "workbench": kinds.append("ammo")
	for index in range(kinds.size()):
		if ui.workshop_section=="construction" and CampaignCycle.RECIPES.has(kinds[index]):_build_card(ui,body,kinds[index],index)
		elif CampFoodCatalog.RECIPES.has(kinds[index]):_camp_card(ui,body,kinds[index],index)
		else:_recipe_card(ui,body,kinds[index],index)
	if ui.workshop_section=="workbench":
		var service:=ui.button(window,"保养 · 零件1 材料1",Vector2(25,760),Vector2(210,38),func():_start(ui,"service_tools"))
		service.disabled=game.cycle.phase!="day" or game.production.condition>=100 or not game.inventory.can_take(GearCatalog.PROJECTS["service_tools"]["cost"])
		service.tooltip_text="恢复工作台工具状态60。低于21时效率降低15%，完全损坏时降低35%；无需重新制作整套工具。"
	if ui.workshop_section == "campaign":
		var y := ceilf(kinds.size()/2.0)*180+12
		ui.button(body,"点燃炉火 · 燃料1",Vector2(0,y),Vector2(332,42),func(): game.expansion.ignite(game); ui._create_workshop())
		ui.button(body,"夜间取暖 "+("开" if game.expansion.use_night_heat else "关"),Vector2(350,y),Vector2(332,42),func(): game.expansion.use_night_heat = not game.expansion.use_night_heat; ui._create_workshop())
		ui.button(body,"净水泵 "+("开" if game.expansion.pump_on else "关"),Vector2(700,y),Vector2(332,42),func(): game.expansion.pump_on = not game.expansion.pump_on; ui._create_workshop())
		ui.label(body,"夜间取暖出发前扣燃料，每份烧8小时；净水泵每日燃料1换水3。",Vector2(0,y+57),Vector2(1050,40),15)
		body.custom_minimum_size.y = y+110
	elif ui.workshop_section!="production":
		var count: int = game.expansion.gear.size() if ui.workshop_section == "storage" else kinds.size()
		body.custom_minimum_size.y = maxf(180,ceilf(count/2.0)*180+10)
	window.draw.connect(func():
		if ui.workshop_section=="workbench":
			if game.facility.tier>=2:FacilityArt.prop(window,8 if game.facility.tier==2 else 9,Rect2(43,604,170,140))
			else:RealismAssets.prop(window,1,Rect2(43,636,170,104))
		elif ui.workshop_section=="kitchen":
			if game.stove.tier>=2:FacilityArt.prop(window,10 if game.stove.tier==2 else 11,Rect2(43,600,170,150))
			else:RealismAssets.prop(window,2,Rect2(66,610,125,132))
	)
	return window


static func _recipe_card(ui: CampaignInterface, body: Control, kind: String, index: int) -> void:
	var game := ui.game
	var basic := kind in ["cook","craft","repair_shelter"]
	var task := "repair" if kind == "repair_shelter" else kind
	var recipe: Dictionary = TaskCatalog.TASKS[task] if basic else GearCatalog.recipe(kind)
	var actor: Survivor = game.survivors[game.selected_id]
	var name: String = recipe["label"] if basic else recipe["name"]
	var station := "stove" if kind == "cook" else FacilitySystem.station_for(kind)
	var minimum := int(FacilitySystem.RECIPES.get(kind,{}).get("minimum",FacilitySystem.REQUIREMENTS.get(kind,1)))
	var locked: bool = int(game.facilities.levels[station]) < minimum
	var card := ui.panel(body,Vector2((index%2)*535,(index/2)*180),Vector2(520,166),GameUi.SURFACE)
	card.draw.connect(func():
		if GearCatalog.ITEMS.has(kind):
			EquipmentArt.icon(card,{"kind":kind,"slot":GearCatalog.ITEMS[kind]["slot"],"broken":false},Vector2(33,33))
		else: HudIcons.draw(card,"meals" if station == "stove" else "tools",Vector2(33,33),25,game.GOLD)
	)
	ui.label(card,"房屋维修" if kind=="repair_shelter" else name,Vector2(65,15),Vector2(330,30),20,game.GOLD)
	ui.label(card,"Lv.%d" % minimum,Vector2(410,17),Vector2(100,28),14,game.GOLD)
	var output: Dictionary = CharacterAbilities.cooking_output(actor) if kind == "cook" else FacilitySystem.cooking_output(kind,actor) if kind in ["cook_batch","cook_stew","cook_pot"] else recipe.get("output",{})
	var line: String = ("每批：" if kind == "cook" else "")+ShelterInventory.describe(recipe["cost"])
	if not output.is_empty(): line += " → "+ShelterInventory.describe(output)
	ui.label(card,line,Vector2(16,56),Vector2(488,28),15)
	var hint: String = "房屋结构 +18（上限100）" if kind == "repair_shelter" else "用于制造和设施装配；逐件加工。" if kind=="craft" else "现场制作；取消退还材料。" if basic else GearCatalog.describe(kind) if GearCatalog.ITEMS.has(kind) else FacilitySystem.RECIPES[kind]["hint"] if FacilitySystem.RECIPES.has(kind) else "用于手枪，射击会引来尸群。" if kind == "ammo" else "使用已带回的战役零件。"
	var detail:=ui.label(card,hint,Vector2(16,87),Vector2(488,26),14)
	detail.tooltip_text=hint;detail.mouse_filter=Control.MOUSE_FILTER_PASS
	var duration: float = TaskCatalog.duration_for(task,actor) if basic else float(recipe["seconds"])
	var action := ui.button(card,("维修" if kind == "repair_shelter" else "烹饪" if station == "stove" else "制作")+" · 约%.1f秒" % (duration/(game.facilities.rate(station)*(game.production.rate() if station=="workbench" else 1.0))),Vector2(340,120),Vector2(164,34),func(): WorkshopProductionView.arrange(ui,kind) if kind in WorkshopProduction.KINDS else _basic(ui,task) if basic else _start(ui,kind))
	if kind in WorkshopProduction.KINDS:
		WorkshopProductionView.controls(ui,card,kind);action.text="安排生产"
	if locked: action.text="未解锁"
	ui.workshop_recipes[kind] = action
	var error: String = game.facilities.job_error(game,kind)
	if kind == "repair_shelter" and game.upkeep.integrity >= 100: error = "房屋结构已完整。"
	if kind in ["radio","pump","beacon"]:
		if game.expansion.stage != {"radio":0,"pump":2,"beacon":3}[kind] or not game.expansion.parts.has(recipe["part"]) or (kind == "beacon" and not game.expansion.parts.has("power_cell")): error = "需要对应阶段和已入库的战役零件。"
	action.disabled = game.cycle.phase != "day" or locked or not error.is_empty() or not game.inventory.can_take(recipe["cost"]) or actor.health <= 0
	action.tooltip_text = error if not error.is_empty() else "缺料："+game.inventory.missing_text(recipe["cost"]) if not game.inventory.can_take(recipe["cost"]) else "耗时随人物专长、状态和设施效率变化。"
	if kind in WorkshopProduction.KINDS:
		action.disabled=game.cycle.phase!="day" or locked or actor.health<=0
		action.tooltip_text="逐件开工时扣料，缺料时等待。重新安排会替换该物品的原计划。"
		if not game.inventory.can_take(recipe["cost"]):action.tooltip_text+="\n"+game.inventory.missing_text(recipe["cost"])
	if kind == "cook":
		ui.label(card,"批数",Vector2(16,123),Vector2(52,27),14)
		ui.kitchen_batches = SpinBox.new()
		ui.kitchen_batches.position = Vector2(70,120)
		ui.kitchen_batches.size = Vector2(90,34)
		ui.kitchen_batches.min_value = 1
		ui.kitchen_batches.max_value = 3
		ui.kitchen_batches.value = 1
		card.add_child(ui.kitchen_batches)
	# A locked recipe keeps readable text; the state and button explain the gate.


static func _basic(ui: CampaignInterface, task: String) -> void:
	var count := int(ui.kitchen_batches.value) if task == "cook" else 1
	ui.game.select_task(task)
	ui.game.batch_count.value = count
	ui.game.assign_selected()
	ui.game.context_open = false
	CampaignPanels.resume(ui.game)
	ui.game._refresh_hud()


static func _start(ui: CampaignInterface, kind: String) -> void:
	if ui.game.expansion.start_job(ui.game,kind): CampaignPanels.resume(ui.game)
	else: ui._create_workshop()


static func _storage_card(ui: CampaignInterface, body: Control, item: Dictionary, index: int) -> void:
	var game := ui.game
	var kind: String = item["kind"]
	var card := ui.panel(body,Vector2((index%2)*535,(index/2)*180),Vector2(520,166),GameUi.SURFACE)
	card.draw.connect(func(): EquipmentArt.icon(card,{"kind":kind,"slot":GearCatalog.ITEMS[kind]["slot"],"broken":item["durability"] <= 0},Vector2(35,32)))
	ui.label(card,GearCatalog.ITEMS[kind]["name"]+" · #%02d" % int(item["id"]),Vector2(65,15),Vector2(435,30),20,game.GOLD)
	ui.label(card,"耐久%d/%d · %s" % [item["durability"],GearCatalog.ITEMS[kind]["durability"],"仓库" if item["owner"] == "" else PeopleCatalog.DATA[item["owner"]]["name"]],Vector2(16,57),Vector2(488,30),17)
	ui.label(card,GearCatalog.describe(kind),Vector2(16,92),Vector2(488,25),14)
	var owner_choice := OptionButton.new()
	owner_choice.position = Vector2(16,122); owner_choice.size = Vector2(226,32)
	owner_choice.add_item("仓库（未装备）",0)
	for actor_id in range(game.survivors.size()):
		var actor: Survivor = game.survivors[actor_id]
		if actor.health <= 0: continue
		owner_choice.add_item(actor.display_name,actor_id+1)
		if item["owner"] == actor.person.persona: owner_choice.select(owner_choice.item_count-1)
	owner_choice.item_selected.connect(func(row: int):
		game.expansion.assign_gear(game,int(item["id"]),owner_choice.get_item_id(row)-1)
		ui._create_workshop()
	)
	owner_choice.disabled = not game.cycle.phase in ["day","planning"]
	card.add_child(owner_choice)
	ui.workshop_owner_choices[int(item["id"])] = owner_choice
	var repair := ui.button(card,"维修 · 材料2",Vector2(258,122),Vector2(246,32),func():
		if game.expansion.start_job(game,"repair",int(item["id"])): CampaignPanels.resume(game)
		else: ui._create_workshop()
	)
	repair.disabled = kind=="lockpick" or game.cycle.phase != "day" or item["durability"] >= GearCatalog.ITEMS[kind]["durability"] or not game.inventory.can_take({"materials":2})


static func _build_card(ui: CampaignInterface,body: Control,kind: String,index: int) -> void:
	var game:=ui.game
	var recipe:Dictionary=CampaignCycle.RECIPES[kind]
	var existing:int=game.cycle.builds.filter(func(build):return build["type"]==kind).size()
	var maximum:=2 if kind=="bed" else 1
	var card:=ui.panel(body,Vector2((index%2)*535,(index/2)*180),Vector2(520,166),GameUi.SURFACE)
	ui.label(card,recipe["name"],Vector2(80,15),Vector2(310,30),22,game.GOLD)
	ui.label(card,"%d / %d"%[existing,maximum],Vector2(425,17),Vector2(82,28),17)
	ui.label(card,ShelterInventory.describe(recipe["cost"]),Vector2(80,53),Vector2(420,28),17)
	ui.label(card,recipe["hint"],Vector2(16,87),Vector2(488,26),14).tooltip_text=recipe["hint"]
	card.draw.connect(func():
		if kind=="bed":RealismAssets.prop(card,0,Rect2(8,17,64,55))
		else:FacilityArt.prop(card,{"heater":0,"filter":1,"barricade":2}[kind],Rect2(12,12,58,67))
	)
	var action:=ui.button(card,"选择位置 · %d秒"%recipe["seconds"],Vector2(288,120),Vector2(216,34),func():ui._select_build(kind))
	action.disabled=game.cycle.phase!="day" or existing>=maximum or game.cycle.builds.size()>=CampaignCycle.SLOTS.size() or not game.inventory.can_take(recipe["cost"])
	action.tooltip_text="已达到数量上限" if existing>=maximum else "没有空建设位置" if game.cycle.builds.size()>=CampaignCycle.SLOTS.size() else "缺料："+game.inventory.missing_text(recipe["cost"]) if not game.inventory.can_take(recipe["cost"]) else "选中后点击场景内的绿色位置；开工后自动继续。"
	ui.workshop_recipes[kind]=action


static func _camp_card(ui: CampaignInterface,body: Control,kind: String,index: int) -> void:
	var game:=ui.game
	var recipe:Dictionary=CampFoodCatalog.RECIPES[kind]
	var card:=ui.panel(body,Vector2((index%2)*535,(index/2)*180),Vector2(520,166),GameUi.SURFACE)
	ui.label(card,recipe["name"],Vector2(65,15),Vector2(440,30),20,game.GOLD)
	var costs:PackedStringArray=[]
	if not recipe["cost"].is_empty():costs.append(ShelterInventory.describe(recipe["cost"]))
	if not recipe["food"].is_empty():costs.append(CampFoodCatalog.names(recipe["food"]))
	ui.label(card," / ".join(costs) if not costs.is_empty() else "无材料消耗",Vector2(16,56),Vector2(488,28),15)
	ui.label(card,recipe["hint"],Vector2(16,87),Vector2(488,26),14).tooltip_text=recipe["hint"]
	card.draw.connect(func():
		if recipe.has("build") or kind in ["settling_filter","backup_power"]:FacilityArt.prop(card,{"planter":7,"pantry":4,"trap":3,"settling_filter":6,"backup_power":12}.get(kind,7),Rect2(12,8,42,42))
		elif not recipe["food"].is_empty():CampFoodCatalog.draw_icon(card,recipe["food"].keys()[0],Vector2(33,33),24)
		else:HudIcons.draw(card,"water" if ui.workshop_section=="water" else "meals",Vector2(33,33),24,game.GOLD)
	)
	var error:String=game.camp.food.error(game,kind,game.selected_id)
	var action:=ui.button(card,("建造" if recipe.has("build") or kind in ["settling_filter","backup_power"] else "开始")+" · %d秒"%recipe["seconds"],Vector2(340,120),Vector2(164,34),func():
		if game.camp.food.start_job(game,kind):CampaignPanels.resume(game)
		else:ui._create_workshop()
	)
	action.disabled=not error.is_empty();action.tooltip_text=error if not error.is_empty() else "开工后自动收起面板并继续时间。"
	ui.workshop_recipes[kind]=action
