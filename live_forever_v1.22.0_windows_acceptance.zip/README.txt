封锁区：余生 v1.22.0 Windows 一键验收

完整解压到可写文件夹，主动运行 windows_acceptance.cmd；默认约30分钟。
独立验收程序会自动操作并生成 AcceptanceResults 文件夹，不使用正常游戏存档。
正常玩游戏只需运行 LiveForever.exe，不要运行验收脚本。
本版 Windows 真机验收仍待完成。Linux 图形预检不代表 Windows 实测通过。
源码提交：10793f71a3b15094a72ab985c779af824d7b79e6
