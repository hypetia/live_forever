封锁区：余生 v1.18.0
新版含建造设施美术、独立装备栏和同款多把武器的逐件分配。
体验营地新机制请新开战役。游戏中O分配装备、K制作，F5管理营地，F6保存、F9读档、F11全屏。
源码、玩法与验证：https://github.com/hypetia/live_forever
运行包放在GitHub下载分支 downloads-v1.18.0。
Linux x86_64：完整解压，运行 ./LiveForever.x86_64；必要时 chmod +x LiveForever.x86_64。
