封锁区：余生 v1.20.0
新版整理夜间准备、制作、装备、营地和人物界面：地图、岗位、物资分栏，统一配色与导航。
建议F2新开战役。游戏中O分配装备、K制作，F5管理营地，F6保存、F9读档、F11全屏。
源码、玩法与验证：https://github.com/hypetia/live_forever
运行包放在GitHub下载分支 downloads-v1.20.0。
Linux x86_64：完整解压，运行 ./LiveForever.x86_64；必要时 chmod +x LiveForever.x86_64。
