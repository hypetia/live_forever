封锁区：余生 v1.17.0
新版含2D人物、场景与家具，以及营地关系和食物疾病循环。
体验营地新机制请新开战役。游戏中F5管理营地，F6保存、F9读档、F11全屏。
源码、玩法与验证：https://github.com/hypetia/live_forever
运行包放在GitHub下载分支 downloads-v1.17.0。
Linux x86_64：完整解压，运行 ./LiveForever.x86_64；必要时 chmod +x LiveForever.x86_64。
